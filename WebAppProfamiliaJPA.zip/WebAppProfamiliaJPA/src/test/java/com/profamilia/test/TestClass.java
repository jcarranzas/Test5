/*
 * Profamilia
 * 2016  * 
 */
package com.profamilia.test;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public class TestClass {

    /**
     * @param args
     */
    public static void main(String[] args) {
        String password = "admin";//$2a$10$nj7zREn0ftqUvmWk7djE..ThUUYoI0qMCzkkIVBFMX4V7eHhYE04q
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        System.out.println("BCryptPasswordEncoder--> " + passwordEncoder.encode(password));

    }

}
