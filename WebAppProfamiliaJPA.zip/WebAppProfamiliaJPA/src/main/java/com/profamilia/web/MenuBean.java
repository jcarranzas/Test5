/*
 * Profamilia
 * 2016  * 
 */
package com.profamilia.web;

import com.profamilia.model.Menu;
import com.profamilia.model.Perfil;
import com.profamilia.model.util.Constantes;
import com.profamilia.service.impl.MenuServiceImpl;
import com.profamilia.service.impl.PerfilServiceImpl;
import com.profamilia.web.util.FacesUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@ManagedBean
@ViewScoped
public class MenuBean implements Serializable {

    private static final long serialVersionUID = -684815355866740159L;

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @ManagedProperty(value = "#{menuServiceImpl}")
    private MenuServiceImpl menuServiceImpl;
    private Menu menuSeleccionado = new Menu();
    private Menu menuAEditar = new Menu();
    private List<Menu> listaSubsMenus = null;
    private List<Menu> listaMenus = new ArrayList<Menu>();
    private long codigoSubmenu = 0;
    private String codigoABuscar;
    private int perfilId;
    @ManagedProperty(value = "#{perfilServiceImpl}")
    private PerfilServiceImpl perfilServiceImpl;

    public String guardar() {

        logger.info("Menu: " + menuSeleccionado.getMenuId() + "Perfil: " + perfilId);
        Perfil p = getPerfilServiceImpl().getById(perfilId);
        menuSeleccionado.setPerfil(p);

        if (codigoSubmenu != 0) {
            Menu subMenu = menuServiceImpl.getById(codigoSubmenu);
            menuSeleccionado.setSubmenu(subMenu);

            if (menuSeleccionado.getPerfil().getPerfilId().equals(menuSeleccionado.getSubmenu().getPerfil().getPerfilId())) {

                if (menuSeleccionado.getMenuId() == 0) {
                    try {

                        menuServiceImpl.guardar(menuSeleccionado);
                        FacesUtils.showFacesMessage("Menu guardado.", 3);
                    } catch (Exception e) {
                        FacesUtils.showFacesMessage("Menu NO guardado.", 1);
                    }
                }
            } else {
                FacesUtils.showFacesMessage("Menu NO guardado, seleccione el mismo Autorizado del menu padre.", 4);
            }
        } else if (menuSeleccionado.getMenuId() == 0) {
            try {

                menuServiceImpl.guardar(menuSeleccionado);
                FacesUtils.showFacesMessage("Menu guardado.", 3);

            } catch (Exception e) {
                FacesUtils.showFacesMessage("Menu NO guardado.", 1);
            }
        }
        return null;
    }

    public void formGuardar() {
        codigoSubmenu = 0;
        if (menuAEditar.getSubmenu() != null) {
            logger.info(" menuSeleccionado: " + menuAEditar.getMenuId() + " SubMenu: " + menuAEditar.getSubmenu().toString());
            codigoSubmenu = menuAEditar.getSubmenu().getMenuId();
        }

        if (menuAEditar != null && menuAEditar.getPerfil() != null) {
            logger.info(" selectedMenu: " + menuAEditar.getMenuId() + " Perfil: " + menuAEditar.getPerfil().toString());
            perfilId = menuAEditar.getPerfil().getPerfilId().intValue();
        }

    }

    public void editar() {

        Perfil p = getPerfilServiceImpl().getById(perfilId);
        menuAEditar.setPerfil(p);

        if (codigoSubmenu != 0) {

            logger.info("Menu: " + menuAEditar.getMenuId() + "Perfil: " + perfilId + " codigoSubmenu: " + codigoSubmenu);

            Menu subMenu = menuServiceImpl.getById(codigoSubmenu);
            menuAEditar.setSubmenu(subMenu);

            if (menuAEditar.getPerfil().getPerfilId().equals(menuAEditar.getSubmenu().getPerfil().getPerfilId())) {
                try {

                    menuServiceImpl.editar(menuAEditar);
                    FacesUtils.showFacesMessage("Menu guardado.", 3);

                } catch (Exception e) {
                    FacesUtils.showFacesMessage("Menu NO guardado.", 1);
                }
            } else {
                FacesUtils.showFacesMessage("Menu NO guardado, seleccione el mismo Autorizado del menu padre.", 4);
            }
        } else {
            try {

                menuAEditar.setSubmenu(null);
                menuServiceImpl.editar(menuAEditar);
                FacesUtils.showFacesMessage("Menu guardado.", 3);
            } catch (Exception e) {
                FacesUtils.showFacesMessage("Menu NO guardado.", 1);
            }
        }

    }

    public String nuevo() {
        menuSeleccionado = new Menu();
        menuSeleccionado.setTipo(Constantes.MENU_TIPO_SUBMENU);
        menuAEditar = new Menu();
        codigoSubmenu = 0;
        codigoABuscar = "";
        perfilId = 0;
        return null;
    }

    public String eliminar() {

        try {

            int itemsRelacionados = menuServiceImpl.findItems(Constantes.MENU_TIPO_ITEM, menuSeleccionado.getMenuId()).size();
            logger.info("Menu: " + menuSeleccionado.getMenuId()
                    + "itemsRelacionados: " + itemsRelacionados);

            if (itemsRelacionados == 0) {
                menuServiceImpl.eliminar(menuSeleccionado);
                FacesUtils.showFacesMessage("Menu eliminado.", 3);
                listaMenus = menuServiceImpl.findAll();
            } else {
                FacesUtils.showFacesMessage("Menu NO eliminado, tiene Items relacionados.", 4);
            }

        } catch (Exception e) {
            FacesUtils.showFacesMessage("Menu NO eliminado.", 1);
        }
        return null;
    }

    public int getPerfilId() {
        return perfilId;
    }

    public void setPerfilId(int perfilId) {
        this.perfilId = perfilId;
    }

    public void establecerSubmenu() {
        codigoSubmenu = menuSeleccionado.getSubmenu().getMenuId();
    }

    public void setListaSubsMenus(List<Menu> listaSubsMenus) {
        this.listaSubsMenus = listaSubsMenus;
    }

    public List<Menu> getListaSubsMenus() throws Exception {
        listaSubsMenus = menuServiceImpl.buscarPorTipo(Constantes.MENU_TIPO_SUBMENU);
        return listaSubsMenus;
    }

    public void setMenuSeleccionado(Menu menuSeleccionado) {
        this.menuSeleccionado = menuSeleccionado;
    }

    public Menu getMenuSeleccionado() {
        return menuSeleccionado;
    }

    public List<Menu> getListaMenus() throws Exception {
        listaMenus = menuServiceImpl.findAll();
        return listaMenus;
    }

    public void setListaMenus(List<Menu> listaMenus) {
        this.listaMenus = listaMenus;
    }

    public long getCodigoSubmenu() {
        return codigoSubmenu;
    }

    public void setCodigoSubmenu(long codigoSubmenu) {
        this.codigoSubmenu = codigoSubmenu;
    }

    public String getCodigoABuscar() {
        return codigoABuscar;
    }

    public void setCodigoABuscar(String codigoABuscar) {
        this.codigoABuscar = codigoABuscar;
    }

    public Menu getMenuAEditar() {
        return menuAEditar;
    }

    public void setMenuAEditar(Menu menuAEditar) {
        this.menuAEditar = menuAEditar;
    }

    /**
     * @param menuServiceImpl the menuServiceImpl to set
     */
    public void setMenuServiceImpl(MenuServiceImpl menuServiceImpl) {
        this.menuServiceImpl = menuServiceImpl;
    }

    /**
     * @return the perfilServiceImpl
     */
    public PerfilServiceImpl getPerfilServiceImpl() {
        return perfilServiceImpl;
    }

    /**
     * @param perfilServiceImpl the perfilServiceImpl to set
     */
    public void setPerfilServiceImpl(PerfilServiceImpl perfilServiceImpl) {
        this.perfilServiceImpl = perfilServiceImpl;
    }



}
