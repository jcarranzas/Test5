/*
 * Profamilia
 * 2016  * 
 */
package com.profamilia.web;

import com.profamilia.model.Perfil;
import com.profamilia.model.Usuario;
import com.profamilia.service.impl.PerfilServiceImpl;
import com.profamilia.service.impl.UsuarioServiceImpl;
import com.profamilia.web.util.FacesUtils;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@ManagedBean
@ViewScoped
public class UsuarioBean implements Serializable {

    private static final long serialVersionUID = -6362880980159758544L;

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @ManagedProperty(value = "#{usuarioServiceImpl}")
    private UsuarioServiceImpl usuarioServiceImpl;
    @ManagedProperty(value = "#{perfilServiceImpl}")
    private PerfilServiceImpl perfilServiceImpl;
    private Usuario usuario;
    private Usuario selectedUsuario;
    private List<Usuario> usuarios;
    private int perfilId;

    @PostConstruct
    public void init() {
        usuario = new Usuario();
        selectedUsuario = new Usuario();
        usuarios = usuarioServiceImpl.getUsuarios();
    }

    public Usuario getSelectedUsuario() {
        return selectedUsuario;
    }

    public void setSelectedUsuario(Usuario selectedUsuario) {
        this.selectedUsuario = selectedUsuario;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }


    public int getPerfilId() {
        return perfilId;
    }

    public void setPerfilId(int perfilId) {
        this.perfilId = perfilId;
    }

    public void nuevo() {
        selectedUsuario = new Usuario();
        selectedUsuario.setFechacreacion(new Date());
        selectedUsuario.setFechamodificacion(new Date());
        selectedUsuario.setEstado(1);
        perfilId = 0;

    }

    public void formGuardar() {
        if (selectedUsuario != null && selectedUsuario.getPerfil() != null) {
            logger.info(" selectedUsuario: " + selectedUsuario.getUsuarioId() + " Perfil: " + selectedUsuario.getPerfil().toString());
            perfilId = selectedUsuario.getPerfil().getPerfilId().intValue();
        }
    }

    public void guardar() {

        logger.info("Usuario: " + selectedUsuario.getUsuarioId() + "Perfil: " + perfilId);
        try {
            selectedUsuario.setFechamodificacion(new Timestamp(new Date().getTime()));
            Perfil p = perfilServiceImpl.getById(perfilId);

            selectedUsuario.setPerfil(p);
            usuarioServiceImpl.update(selectedUsuario);
            FacesUtils.showFacesMessage("Usuario guardado", 3);
            usuarios = usuarioServiceImpl.getUsuarios();

        } catch (Exception e) {
            FacesUtils.showFacesMessage("Error: Usuario NO guardado.", 1);
            e.printStackTrace();
        }

    }

    public void insertar() {

        logger.info("Usuario: " + selectedUsuario.getUsuarioId() + "Perfil: " + perfilId);

        try {
            selectedUsuario.setFechacreacion(new Timestamp(new Date().getTime()));
            selectedUsuario.setEstado(1);

            Perfil p = perfilServiceImpl.getById(perfilId);
            selectedUsuario.setPerfil(p);

            usuarioServiceImpl.save(selectedUsuario);

            FacesUtils.showFacesMessage("Usuario guardado", 3);
            usuarios = usuarioServiceImpl.getUsuarios();
        } catch (Exception e) {
            FacesUtils.showFacesMessage("Error: Usuario nuevo NO guardado.", 1);
            e.printStackTrace();
        }

    }

    public void eliminar() {
        logger.info("usuario: " + selectedUsuario.toString());

        try {
            usuarioServiceImpl.delete(selectedUsuario);
            FacesUtils.showFacesMessage("Usuario eliminado", 3);
            usuarios = usuarioServiceImpl.getUsuarios();
        } catch (Exception e) {
            FacesUtils.showFacesMessage("Error: Usuario NO eliminado.", 1);
            e.printStackTrace();
        }

    }

    /**
     * @param usuarioServiceImpl the usuarioServiceImpl to set
     */
    public void setUsuarioServiceImpl(UsuarioServiceImpl usuarioServiceImpl) {
        this.usuarioServiceImpl = usuarioServiceImpl;
    }

    /**
     * @param perfilServiceImpl the perfilServiceImpl to set
     */
    public void setPerfilServiceImpl(PerfilServiceImpl perfilServiceImpl) {
        this.perfilServiceImpl = perfilServiceImpl;
    }

}
