/*
 * Profamilia
 * 2016  * 
 */
package com.profamilia.web;

import com.profamilia.model.Menu;
import com.profamilia.model.Usuario;
import com.profamilia.service.impl.MenuServiceImpl;
import java.io.Serializable;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.MenuModel;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@ManagedBean
@SessionScoped
public class MenuController implements Serializable {

    private static final long serialVersionUID = -379177221533494416L;
    
   @ManagedProperty(value = "#{menuServiceImpl}")
    private MenuServiceImpl menuServiceImpl;
    private List<Menu> lista = null;
    private MenuModel model;
    private String usuarioLogeado = null;
    @SuppressWarnings("unused")
    private Usuario user = null;

    public Usuario getUser() {
        return (Usuario) FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .get("usuario");
    }

    public void setUser(Usuario user) {
        this.user = user;
    }

    public String getUsuarioLogeado() {
        Usuario us
                = (Usuario) FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .get("usuario");
        //usuarioLogeado = us.getUsuario();
        return usuarioLogeado;
    }

    public void setUsuarioLogeado(String usuarioLogeado) {
        this.usuarioLogeado = usuarioLogeado;
    }

    public void listarMenus() {        
        try {
            setLista(menuServiceImpl.findAll());
        } catch (Exception e) {
        }
    }

    public List<Menu> getLista() {
        return lista;
    }

    public void setLista(List<Menu> lista) {
        this.lista = lista;
    }

    public MenuController() {
        listarMenus();
        model = new DefaultMenuModel();
        this.establecerPermisos();
    }

    public void establecerPermisos() {
        /*Usuario us = (Usuario) FacesContext.getCurrentInstance()
                .getExternalContext()
                .getSessionMap().get("usuario");
        for (Menu m : lista) {
            if (m.getTipo().equals("S")
                    && m.getTipoUsuario().equals(us.getTipo())) {
                DefaultSubMenu firstSubmenu
                        = new DefaultSubMenu(m.getNombre());
                for (Menu i : lista) {
                    Menu submenu = i.getSubmenu();
                    if (submenu != null) {
                        if (submenu.getMenuId() == m.getMenuId()) {
                            DefaultMenuItem item = new DefaultMenuItem(i.getNombre());
                            item.setUrl(i.getUrl());
                            firstSubmenu.addElement(item);
                        }
                    }
                }
                model.addElement(firstSubmenu);
            } else if (m.getSubmenu() == null
                    && m.getTipoUsuario().equals(us.getTipo())) {
                DefaultMenuItem item = new DefaultMenuItem(m.getNombre());
                item.setUrl(m.getUrl());
                model.addElement(item);
            }
        }*/
    }

    public MenuModel getModel() {
        return model;
    }

    public void setModel(MenuModel model) {
        this.model = model;
    }

    public void cerrarSesion() {
        FacesContext.getCurrentInstance()
                .getExternalContext().invalidateSession();
    }

    /*public String mostrarUsuarioLogeado() {
        Usuario us
                = (Usuario) FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .get("usuario");
        return us.getUsuario();
    }*/

    /**
     * @param menuServiceImpl the menuServiceImpl to set
     */
    public void setMenuServiceImpl(MenuServiceImpl menuServiceImpl) {
        this.menuServiceImpl = menuServiceImpl;
    }


}
