/*
 * Profamilia
 * 2016  * 
 */
package com.profamilia.service;


import com.profamilia.model.Usuario;
import com.profamilia.service.impl.UsuarioServiceImpl;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */


@Service("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService{
    
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UsuarioServiceImpl usuarioServiceImpl;
	
	@Transactional(readOnly=true)
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {
		Usuario usuario = usuarioServiceImpl.findByUserName(username);
		logger.info("User : "+usuario);
		if(usuario==null){
			logger.info("User not found");
			throw new UsernameNotFoundException("Username not found"); 
		}
			return new org.springframework.security.core.userdetails.User(usuario.getNombreUsuario(), usuario.getContrasena(), 
				 (usuario.getEstado() == 1), true, true, true, getGrantedAuthorities(usuario));
	}

	
	private List<GrantedAuthority> getGrantedAuthorities(Usuario usuario){
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		
		//for(Perfil perfil : usuario.getPerfiles()){
			//logger.info("UserProfile : "+perfil);
			authorities.add(new SimpleGrantedAuthority("ROLE_"+usuario.getPerfil().getNombrePerfil()));
		//}
		logger.info("authorities :"+authorities);
		return authorities;
	}
	
}
