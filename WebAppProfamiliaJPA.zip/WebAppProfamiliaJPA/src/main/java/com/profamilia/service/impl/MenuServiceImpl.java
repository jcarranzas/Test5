/*
 * Profamilia
 * 2016  * 
 */
package com.profamilia.service.impl;

import com.profamilia.model.Menu;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Component;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@Component
public class MenuServiceImpl {

    @PersistenceContext(unitName = "persistenceDEVDB")
    private EntityManager em;

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public void guardar(Menu menu) {
        em.persist(menu);
    }

    public void editar(Menu menu) {
        em.persist(menu);
    }

    public void eliminar(Menu menu) {
        em.remove(menu);
    }

    public Menu getById(long menuId) {
        return (Menu) em.createNamedQuery("").getSingleResult();
    }

    public List<Menu> buscarPorTipo(String tipo)
            throws Exception {
        List<Menu> listMenu = new ArrayList<Menu>();
        return listMenu;
    }

    public List<Menu> findAll()
            throws Exception {
        List<Menu> listMenu = new ArrayList<Menu>();
        return listMenu;
    }

    public List<Menu> findByState(boolean state) throws Exception {
        List<Menu> listMenu = new ArrayList<Menu>();
        return listMenu;
    }

    public List<Menu> findItems(String tipo, long id)
            throws Exception {
        List<Menu> listMenu = new ArrayList<Menu>();
        return listMenu;
    }

}
