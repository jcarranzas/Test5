/*
 * Profamilia
 * 2016  * 
 */
package com.profamilia.service.impl;

import com.profamilia.model.Usuario;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@Component
public class UsuarioServiceImpl {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @PersistenceContext(unitName="persistenceDEVDB") 
    private EntityManager em;

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public void save(Usuario usuario) {
        em.persist(usuario);
    }

    public void update(Usuario usuario) {
        em.persist(usuario);
    }

    public void delete(Usuario usuario) {
        em.remove(usuario);
    }

    public Usuario findByUserName(String username) {
        return (Usuario) em.createNamedQuery("Usuario.findByUsuarioId").setParameter("usuarioId",new BigDecimal(1)).getSingleResult();
    }

    public List<Usuario> getUsuarios() {
        List<Usuario> listUsuario = new ArrayList<Usuario>();
        return listUsuario;
    }

}
