/*
 * Profamilia
 * 2016  * 
 */
package com.profamilia.service.impl;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */

import com.profamilia.model.Perfil;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Component;


@Component
public class PerfilServiceImpl {

    @PersistenceContext(unitName="persistenceDEVDB") 
    private EntityManager em;

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public void save(Perfil perfil) {
        em.persist(perfil);
    }

    public void update(Perfil perfil) {
        em.persist(perfil);
    }

    public void delete(Perfil perfil) {
        em.remove(perfil);
    }

    public List<Perfil> findAll() {
         List<Perfil> listPerfil= new ArrayList<Perfil>();
        return listPerfil;
    }

    public Perfil getById(int perfilId) {
        return (Perfil)em.createNamedQuery("").getSingleResult();
    }

}
