/*
 * Profamilia
 * 2016  * 
 */
package com.profamilia.configuration;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
//INFO: Class extends AbstractSecurityWebApplicationInitializer, it will load the springSecurityFilterChain automatically
public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {



}
